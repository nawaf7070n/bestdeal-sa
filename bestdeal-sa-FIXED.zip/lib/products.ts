export const products = [
  { id: 1, name: 'ايفون 15 برو ماكس 256GB', category: 'جوالات', price: 4799, oldPrice: 5299, image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=500' },
  { id: 2, name: 'سامسونج جالكسي S24 الترا', category: 'جوالات', price: 4299, oldPrice: 4799, image: 'https://images.unsplash.com/photo-1610945265078-3858a2d2a1b9?w=500' },
  { id: 3, name: 'سماعة AirPods Pro 2', category: 'سماعات', price: 899, oldPrice: 1099, image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=500' },
  { id: 4, name: 'لابتوب ماك بوك اير M2', category: 'لابتوبات', price: 3999, oldPrice: 4499, image: 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=500' },
  { id: 5, name: 'ساعة ابل واتش Series 9', category: 'ساعات', price: 1599, oldPrice: 1899, image: 'https://images.unsplash.com/photo-1555421689-3f034debb7a6?w=500' },
  { id: 6, name: 'بلايستيشن 5', category: 'ألعاب', price: 1999, oldPrice: 2299, image: 'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=500' },
  { id: 7, name: 'ايباد برو 12.9', category: 'تابلت', price: 3499, oldPrice: 3999, image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=500' },
  { id: 8, name: 'سماعة سوني WH-1000XM5', category: 'سماعات', price: 1199, oldPrice: 1399, image: 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=500' },
]
