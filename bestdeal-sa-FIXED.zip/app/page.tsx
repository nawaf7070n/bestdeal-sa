'use client'
import { useState } from 'react'
import { products } from '../lib/products'

export default function Home() {
  const [cart, setCart] = useState<any[]>([])
  const [query, setQuery] = useState('')

  const filtered = products.filter(p => p.name.includes(query) || p.category.includes(query))

  const addToCart = (p:any) => {
    setCart([...cart, p])
    alert(`تمت إضافة ${p.name} للسلة`)
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-black text-white p-4 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <h1 className="text-2xl font-bold text-yellow-400">BestDeal SA</h1>
          <input 
            value={query}
            onChange={e=>setQuery(e.target.value)}
            placeholder="ابحث مثل أمازون - ايفون، سماعات، لابتوب..."
            className="flex-1 max-w-2xl p-2.5 rounded text-black outline-none"
          />
          <div className="bg-yellow-400 text-black px-4 py-2 rounded font-bold">السلة ({cart.length})</div>
        </div>
      </header>

      {/* Banner */}
      <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-6 text-center">
        <h2 className="text-3xl font-black">أفضل العروض مثل نون واكسترا وجرير 🔥</h2>
        <p className="mt-2">شحن مجاني + ضمان سنتين + دفع عند الاستلام</p>
      </div>

      {/* Products */}
      <main className="max-w-7xl mx-auto p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-6">
        {filtered.map(p=>(
          <div key={p.id} className="bg-white rounded-xl shadow hover:shadow-xl transition p-3 border">
            <img src={p.image} alt={p.name} className="h-48 w-full object-contain" />
            <div className="mt-3">
              <span className="text-xs bg-gray-100 px-2 py-1 rounded">{p.category}</span>
              <h3 className="font-bold mt-2 line-clamp-2">{p.name}</h3>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-xl font-black text-green-600">{p.price} ر.س</span>
                <span className="text-sm line-through text-gray-400">{p.oldPrice} ر.س</span>
              </div>
              <button onClick={()=>addToCart(p)} className="w-full mt-3 bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-2.5 rounded-lg">أضف للسلة</button>
            </div>
          </div>
        ))}
      </main>

      <footer className="mt-12 bg-black text-white text-center p-6">
        BestDeal SA © 2026 - متجر إلكترونيات مثل أمازون ونون
      </footer>
    </div>
  )
}
