import './globals.css'

export const metadata = {
  title: 'BestDeal SA - متجر إلكترونيات',
  description: 'متجر إلكترونيات مثل أمازون ونون واكسترا وجرير',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-gray-50">{children}</body>
    </html>
  )
}
